from django.contrib import admin
from imdb.models import Actor,Movie

# Register your models here.
admin.site.register(Actor)
admin.site.register(Movie)

