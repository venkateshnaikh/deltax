from django.shortcuts import render
from imdb.models import Movie
from django.views import generic

# Create your views here.
def index(request):
	return render(request,"index.html")

def addmovie(request):
	return render(request,"addmovie.html")

class MovieListView(generic.ListView):
    model = Movie
    template_name = 'movie_list.html'
